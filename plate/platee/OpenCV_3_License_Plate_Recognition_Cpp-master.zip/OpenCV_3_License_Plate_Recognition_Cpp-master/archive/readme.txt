The video pretty much explains it all:
https://www.youtube.com/watch?v=euG7-o9oPKg
